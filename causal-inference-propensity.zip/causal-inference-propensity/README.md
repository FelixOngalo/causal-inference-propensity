# Causal Inference from Observational Data: Propensity Scores

**Question:** *(fill in)* How badly does confounding bias a naive treated-vs-untreated comparison, and which methods (regression adjustment, inverse-propensity weighting, propensity matching) recover the true effect?

**Key findings:** *(fill in after running: naive bias, each method's estimate vs. the true effect of 5, covariate balance before/after weighting)*

**Tools:** R, tidyverse, logistic-regression propensity scores, bootstrap CIs, Quarto report with the potential-outcomes framework and short proofs

## Reproduce

1. `install.packages(c("tidyverse"))`
2. Run `R/00_simulate_data.R`, then `R/01_analyze.R`
3. Render `reports/report.qmd`

## Data

Simulated observational study (3,000 people): age, income and urban status drive both treatment uptake and the outcome; the true treatment effect is exactly +5 and is hidden from the analysis code.

## Method in brief

1. Naive difference in means (biased by design).
2. Regression adjustment.
3. Propensity score via logistic regression, then inverse-propensity weighting (trimmed) and 1:1 nearest-neighbour matching on the logit score.
4. Bootstrap 95% CIs (propensity model refit in every resample); covariate balance via standardized mean differences.

## Key concepts

| Concept | Meaning |
|---|---|
| Potential outcomes | Y(1) and Y(0) for each person; only one is observed |
| Confounding | A variable driving both treatment and outcome, creating selection bias |
| Unconfoundedness + overlap | The two assumptions that make causal estimation from observational data possible |
| Propensity score | P(treated given covariates); balancing on it balances all covariates (Rosenbaum-Rubin) |
| IPW | Weight by inverse probability of the treatment received to build a balanced pseudo-population |
| SMD | Standardized mean difference; below 0.1 is the usual "balanced" rule of thumb |

## Project structure

```
R/00_simulate_data.R    data with confounding and a known true effect
R/causal_functions.R    propensity scores, four estimators, balance, bootstrap
R/01_analyze.R          run everything, save results
reports/report.qmd      framework, short proofs, results, diagnostics
```

## Limitations

- Assumes all confounders are measured; real studies cannot verify this.
- Correctly specified propensity model by construction.
- Simple matching without calipers; use MatchIt/WeightIt for real work.
- *(add your own)*
