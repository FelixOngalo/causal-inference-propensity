# Simulate an observational study with CONFOUNDING and a KNOWN true
# treatment effect (+5). Older, higher-income people are both more
# likely to take the treatment AND have higher outcomes regardless of
# it -- so a naive treated-vs-untreated comparison is biased upward.
# Knowing the true answer (5) is what lets this project check which
# causal methods actually remove that bias.
library(dplyr)
library(readr)

set.seed(42)
n <- 3000

df <- tibble(
  age    = rnorm(n, 40, 10),
  income = rnorm(n, 50, 15),
  urban  = rbinom(n, 1, 0.6)
) |>
  mutate(
    p_treat = plogis(-0.5 + 0.05 * (age - 40) + 0.04 * (income - 50) + 0.5 * urban),
    treated = rbinom(n, 1, p_treat),
    outcome = 20 + 0.3 * age + 0.2 * income + 3 * urban + 5 * treated + rnorm(n, 0, 5)
  ) |>
  select(-p_treat)   # the true assignment probability is hidden from the analyst

write_csv(df, "data/raw/observational_study.csv")
cat("Simulated", n, "people; treated share:", round(mean(df$treated), 3), "\n")
cat("TRUE treatment effect: 5\n")
