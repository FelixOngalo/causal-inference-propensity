library(dplyr)
library(readr)
source("R/causal_functions.R")

df <- read_csv("data/raw/observational_study.csv", show_col_types = FALSE)
true_effect <- 5

estimators <- list(
  `Naive difference` = ate_naive,
  `Regression adjustment` = ate_regression,
  `IPW (propensity weighting)` = ate_ipw,
  `Matching on propensity (ATT)` = att_matching
)

results <- lapply(names(estimators), function(nm) {
  est <- estimators[[nm]](df)
  ci  <- bootstrap_ci(df, estimators[[nm]], B = 200)
  tibble(method = nm, estimate = est, ci_low = ci[[1]], ci_high = ci[[2]],
         bias = est - true_effect)
}) |> bind_rows()

cat("True effect:", true_effect, "\n")
print(results)

d <- add_propensity(df)
balance <- tibble(
  covariate = covariates,
  smd_before = standardized_mean_diff(d),
  smd_after_ipw = standardized_mean_diff(d, ipw_weights(d))
)
cat("\nCovariate balance (|SMD| < 0.1 is balanced):\n")
print(balance)

saveRDS(list(df = d, results = results, balance = balance, true_effect = true_effect),
        "data/clean/causal_results.rds")
