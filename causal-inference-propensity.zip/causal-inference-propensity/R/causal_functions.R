# Estimators of the average treatment effect (ATE) from observational
# data, each handling confounding differently. Every estimator takes
# the raw data frame and fits its own propensity model, so bootstrap
# resampling (bootstrap_ci) propagates that estimation uncertainty too.

library(dplyr)

covariates <- c("age", "income", "urban")

#' Propensity score e(x) = P(treated = 1 | x), via logistic regression.
#' Adds columns ps and logit_ps.
add_propensity <- function(df) {
  fit <- glm(reformulate(covariates, response = "treated"), data = df, family = binomial)
  df$ps <- predict(fit, type = "response")
  df$logit_ps <- qlogis(df$ps)
  df
}

#' Naive difference in means. Biased under confounding.
ate_naive <- function(df) {
  mean(df$outcome[df$treated == 1]) - mean(df$outcome[df$treated == 0])
}

#' Regression adjustment: outcome ~ treated + covariates; the
#' coefficient on `treated` is the adjusted effect (correct if the
#' outcome model is linear in the covariates, as it is here).
ate_regression <- function(df) {
  fit <- lm(reformulate(c("treated", covariates), response = "outcome"), data = df)
  unname(coef(fit)["treated"])
}

#' Inverse-propensity weighting (Hajek form). Each person is weighted
#' by 1 / P(receiving the treatment they actually got), which builds a
#' pseudo-population where treatment is independent of the covariates.
#' Scores outside [trim, 1 - trim] are dropped: near 0 or 1 the weights
#' explode and a few people dominate the estimate.
ate_ipw <- function(df, trim = 0.01) {
  d <- add_propensity(df) |> filter(ps > trim, ps < 1 - trim)
  w <- ifelse(d$treated == 1, 1 / d$ps, 1 / (1 - d$ps))
  m1 <- sum(w * d$outcome * d$treated) / sum(w * d$treated)
  m0 <- sum(w * d$outcome * (1 - d$treated)) / sum(w * (1 - d$treated))
  m1 - m0
}

#' 1:1 nearest-neighbour matching (with replacement) on the logit of
#' the propensity score. Each treated unit is paired with the control
#' closest in propensity. Estimates the effect on the TREATED (ATT);
#' here the true effect is constant, so ATT = ATE = 5.
att_matching <- function(df) {
  d <- add_propensity(df)
  treated  <- d[d$treated == 1, ]
  controls <- d[d$treated == 0, ]
  nearest <- vapply(treated$logit_ps, function(x) which.min(abs(controls$logit_ps - x)), integer(1))
  mean(treated$outcome - controls$outcome[nearest])
}

#' Standardized mean difference of each covariate between treated and
#' control, optionally using weights for the group means. |SMD| < 0.1
#' is the usual rule of thumb for "balanced".
standardized_mean_diff <- function(df, weights = NULL) {
  if (is.null(weights)) weights <- rep(1, nrow(df))
  sapply(covariates, function(v) {
    t1 <- df$treated == 1; t0 <- !t1
    m1 <- weighted.mean(df[[v]][t1], weights[t1])
    m0 <- weighted.mean(df[[v]][t0], weights[t0])
    pooled_sd <- sqrt((var(df[[v]][t1]) + var(df[[v]][t0])) / 2)
    (m1 - m0) / pooled_sd
  })
}

#' IPW weights for a data frame (used for the balance check).
ipw_weights <- function(df) {
  ifelse(df$treated == 1, 1 / df$ps, 1 / (1 - df$ps))
}

#' Percentile bootstrap CI for any estimator function(df) -> number.
bootstrap_ci <- function(df, estimator, B = 200, seed = 1) {
  set.seed(seed)
  est <- replicate(B, estimator(df[sample(nrow(df), replace = TRUE), ]))
  quantile(est, c(0.025, 0.975))
}
